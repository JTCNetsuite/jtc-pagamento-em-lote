/**
 * @NAPIVersion 2.x
 * @NScriptType MapReduceScript
 */
define(["require", "exports", "N/log", "../models/jtc_pagar_contas_mr_MSR"], function (require, exports, log, MSR) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.summarize = exports.map = exports.getInputData = void 0;
    var getInputData = function () {
        try {
            return MSR.getInputData();
        }
        catch (error) {
            log.error("jtc_pagar_contas_MR.getInputData", error);
        }
    };
    exports.getInputData = getInputData;
    var map = function (ctx) {
        try {
            MSR.map(ctx);
        }
        catch (error) {
            log.error("jtc_pagar_contas_MR.map", error);
        }
    };
    exports.map = map;
    var summarize = function (ctx) {
        try {
            MSR.summarize(ctx);
        }
        catch (error) {
            log.error("jtc_pagar_contas_MR.Summarize", error);
        }
    };
    exports.summarize = summarize;
});

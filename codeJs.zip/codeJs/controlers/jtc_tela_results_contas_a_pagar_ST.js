/**
 * @NAPIVersion 2.x
 * @NScriptType Suitelet
 */
define(["require", "exports", "../models/jtc_tela_pagar_contas_st_MSR"], function (require, exports, MSR) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    var onRequest = function (ctx) {
        try {
            MSR.onRequest(ctx);
        }
        catch (error) {
        }
    };
    exports.onRequest = onRequest;
});

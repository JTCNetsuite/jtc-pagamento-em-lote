/**
 * @NAPIVersion 2.x
 * @NModuleScope public
 */
define(["require", "exports", "N/log", "N/runtime", "../module/jtc_pagar_contas_CTS", "N/record", "N/search"], function (require, exports, log, runtime, jtc_pagar_contas_CTS_1, record, search) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.summarize = exports.map = exports.getInputData = void 0;
    var getInputData = function () {
        try {
            var currScript = runtime.getCurrentScript();
            var idContasPagar = currScript.getParameter({ name: jtc_pagar_contas_CTS_1.constant.SCRIPT_CONTAS_PAGAR_MR.PARAMS.IDS_CONTAS });
            log.debug('id constas', idContasPagar);
            var ids = String(idContasPagar).slice(1, -1).split(",");
            ids.pop();
            log.debug('ids', ids);
            var filters = [];
            for (var i = 0; i < ids.length; i++) {
                filters.push(["internalid", search.Operator.ANYOF, ids[i]], "OR");
            }
            filters.pop();
            log.debug('filters', filters);
            var searchVendorBill = search.create({
                type: search.Type.VENDOR_BILL,
                filters: [
                    ["mainline", search.Operator.IS, "T"],
                    "AND",
                    filters
                ],
                columns: []
            });
            return searchVendorBill;
        }
        catch (error) {
            log.error('jtc_pagar_contas_mr_MSR.getInputData', error);
        }
    };
    exports.getInputData = getInputData;
    var map = function (ctx) {
        try {
            log.debug('ctx', ctx.value);
            var values = JSON.parse(ctx.value);
            var currScript = runtime.getCurrentScript();
            var idRecPgLote = currScript.getParameter({ name: jtc_pagar_contas_CTS_1.constant.SCRIPT_CONTAS_PAGAR_MR.PARAMS.ID_REC_PG_LOTE });
            var conta = currScript.getParameter({ name: jtc_pagar_contas_CTS_1.constant.SCRIPT_CONTAS_PAGAR_MR.PARAMS.CONTA });
            var dt_pgamento = String(currScript.getParameter({ name: jtc_pagar_contas_CTS_1.constant.SCRIPT_CONTAS_PAGAR_MR.PARAMS.DT_PAGAMENTO })).split("/");
            log.debug("dt_pg", dt_pgamento);
            var idTrans = values.id;
            var recPayment = record.transform({
                fromId: idTrans,
                fromType: record.Type.VENDOR_BILL,
                toType: record.Type.VENDOR_PAYMENT
            });
            recPayment.setValue({ fieldId: jtc_pagar_contas_CTS_1.constant.VENDOR_PAYMENT.CONTA, value: conta });
            recPayment.setValue({ fieldId: jtc_pagar_contas_CTS_1.constant.VENDOR_PAYMENT.REC_LOTE, value: idRecPgLote });
            recPayment.setValue({ fieldId: jtc_pagar_contas_CTS_1.constant.VENDOR_PAYMENT.DATA, value: new Date("".concat(dt_pgamento[1], "/").concat(dt_pgamento[0], "/").concat(dt_pgamento[2])) });
            var idPymente = recPayment.save({ ignoreMandatoryFields: true });
            log.audit('idPyament', idPymente);
        }
        catch (error) {
            log.error('jtc_pagar_contas_mr_MSR.getInputData', error);
        }
    };
    exports.map = map;
    var summarize = function (ctx) {
        var currScript = runtime.getCurrentScript();
        var idRecPgLote = currScript.getParameter({ name: jtc_pagar_contas_CTS_1.constant.SCRIPT_CONTAS_PAGAR_MR.PARAMS.ID_REC_PG_LOTE });
        var recordPgLote = record.load({
            type: jtc_pagar_contas_CTS_1.constant.RT_LOTE_PAGAMENTO.ID,
            id: idRecPgLote
        });
        recordPgLote.setValue({ fieldId: jtc_pagar_contas_CTS_1.constant.RT_LOTE_PAGAMENTO.DATA_FIM, value: new Date() });
        recordPgLote.setValue({ fieldId: jtc_pagar_contas_CTS_1.constant.RT_LOTE_PAGAMENTO.STATUS, value: 'FINALIZADO' });
        var idPglote = recordPgLote.save();
        log.audit('idPglote', idPglote);
    };
    exports.summarize = summarize;
});

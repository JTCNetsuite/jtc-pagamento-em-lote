/**
 * @NAPIVersion 2.x
 * @NModuleScope public
 */
define(["require", "exports", "N/ui/serverWidget", "N/log", "../module/jtc_pagar_contas_CTS", "N/record", "N/search", "N/redirect", "N/task"], function (require, exports, UI, log, jtc_pagar_contas_CTS_1, record, search, redirect, task) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    var onRequest = function (ctx) {
        try {
            var form = UI.createForm({
                title: jtc_pagar_contas_CTS_1.constant.FORM.TITLE
            });
            if (ctx.request.method == "GET") {
                getForm(form, ctx);
            }
            else {
                if (ctx.request.parameters.custpage_check == "T" || ctx.request.parameters.custpage_check == true) {
                    var body = ctx.request.parameters;
                    var data_de = body.custpage_date_de;
                    var data_ate = body.custpage_date_ate;
                    var sublist = String(body.custpage_sublista_contasdata).split("/\u0001/");
                    var lines = String(sublist[0]).split("\u0002");
                    var dt_pgamento = body.custpage_data_pg;
                    log.debug('lines', lines);
                    var id_to_send = '';
                    for (var i = 0; i < lines.length; i++) {
                        // log.debug(i, lines[i])
                        var line = lines[i].split("\u0001");
                        if (line[0] == "T") {
                            log.debug("".concat(i), line);
                            id_to_send += "".concat(line[1], ",");
                        }
                    }
                    log.debug('id to send', id_to_send);
                    var recLotePagamento = record.create({
                        type: jtc_pagar_contas_CTS_1.constant.RT_LOTE_PAGAMENTO.ID
                    });
                    recLotePagamento.setValue({ fieldId: jtc_pagar_contas_CTS_1.constant.RT_LOTE_PAGAMENTO.DATA_INICIO, value: new Date() });
                    recLotePagamento.setValue({ fieldId: jtc_pagar_contas_CTS_1.constant.RT_LOTE_PAGAMENTO.STATUS, value: "INICIADO" });
                    var idReturnLotePg = recLotePagamento.save();
                    var mapReduceTask = task.create({
                        taskType: task.TaskType.MAP_REDUCE,
                        scriptId: jtc_pagar_contas_CTS_1.constant.SCRIPT_CONTAS_PAGAR_MR.ID,
                        params: {
                            custscript_jtc_id_contas_a_pagar: JSON.stringify(id_to_send),
                            custscript_id_rec_pag_em_lote: idReturnLotePg,
                            custscript_jtc_conta_pagar: body.custpage_account,
                            custscript_jtc_data_de_pagamento: dt_pgamento
                        }
                    });
                    var idTask = mapReduceTask.submit();
                    redirect.toRecord({
                        id: idReturnLotePg,
                        type: jtc_pagar_contas_CTS_1.constant.RT_LOTE_PAGAMENTO.ID
                    });
                }
                else {
                    postForm(form, ctx);
                }
            }
        }
        catch (e) {
            log.error('jtc_tela_contas_pagar_MSR.onRequest', e);
            throw e;
        }
    };
    exports.onRequest = onRequest;
    var getForm = function (form, ctx) {
        try {
            var fornecedor = form.addField({
                id: jtc_pagar_contas_CTS_1.constant.FORM.FILTERS.FORNECEDOR.ID,
                label: jtc_pagar_contas_CTS_1.constant.FORM.FILTERS.FORNECEDOR.LABEL,
                type: UI.FieldType.SELECT,
                source: String(record.Type.VENDOR)
            });
            var data_de = form.addField({
                id: jtc_pagar_contas_CTS_1.constant.FORM.FILTERS.DATA_DE.ID,
                label: jtc_pagar_contas_CTS_1.constant.FORM.FILTERS.DATA_DE.LABEL,
                type: UI.FieldType.DATE
            }).isMandatory = true;
            var data_ate = form.addField({
                id: jtc_pagar_contas_CTS_1.constant.FORM.FILTERS.DATA_ATE.ID,
                label: jtc_pagar_contas_CTS_1.constant.FORM.FILTERS.DATA_ATE.LABEL,
                type: UI.FieldType.DATE
            }).isMandatory = true;
            form.addSubmitButton({ label: jtc_pagar_contas_CTS_1.constant.FORM.BTN_SUBMIT });
            ctx.response.writePage(form);
        }
        catch (e) {
            log.error('jtc_tela_contas_pagar_MSR.getForm', e);
            throw e;
        }
    };
    var postForm = function (form, ctx) {
        try {
            var body = ctx.request.parameters;
            var vendor = body.custpage_vendor;
            var data_de = body.custpage_date_de;
            var data_ate = body.custpage_date_ate;
            var filters = [];
            form.addField({
                id: jtc_pagar_contas_CTS_1.constant.FORM.DATA_PG.ID,
                label: jtc_pagar_contas_CTS_1.constant.FORM.DATA_PG.LABEL,
                type: UI.FieldType.DATE
            });
            form.addField({
                id: jtc_pagar_contas_CTS_1.constant.FORM.CHECK_PAGE.ID,
                label: jtc_pagar_contas_CTS_1.constant.FORM.CHECK_PAGE.LABEL,
                type: UI.FieldType.CHECKBOX
            }).updateDisplayType({ displayType: UI.FieldDisplayType.HIDDEN }).defaultValue = 'T';
            var account = form.addField({
                id: jtc_pagar_contas_CTS_1.constant.FORM.CONTA.ID,
                label: jtc_pagar_contas_CTS_1.constant.FORM.CONTA.LABEL,
                type: UI.FieldType.SELECT,
                source: 'account'
            });
            if (!!vendor) {
                filters.push([jtc_pagar_contas_CTS_1.constant.VENDOR_BILL.FORNECEDOR, search.Operator.ANYOF, vendor]);
                filters.push("AND");
            }
            if (!!data_de && !!data_ate) {
                filters.push([
                    jtc_pagar_contas_CTS_1.constant.VENDOR_BILL.DATA_VENCIMENTO, search.Operator.WITHIN, data_de, data_ate
                ]);
                filters.push("AND");
            }
            else if (!!data_de) {
                filters.push([
                    jtc_pagar_contas_CTS_1.constant.VENDOR_BILL.DATA_VENCIMENTO, search.Operator.AFTER, data_de
                ]);
                filters.push("AND");
            }
            else if (!!data_ate) {
                filters.push([
                    jtc_pagar_contas_CTS_1.constant.VENDOR_BILL.DATA_VENCIMENTO, search.Operator.BEFORE, data_ate
                ]);
                filters.push("AND");
            }
            filters.push(["mainline", search.Operator.IS, "T"]);
            filters.push("AND");
            filters.push([jtc_pagar_contas_CTS_1.constant.VENDOR_BILL.STATUS, search.Operator.IS, 2]);
            filters.push("AND");
            filters.push(["status", search.Operator.ANYOF, "VendBill:A"]);
            log.debug('filers', filters);
            var sublist = form.addSublist({
                id: jtc_pagar_contas_CTS_1.constant.FORM.SUBLIST.ID,
                label: jtc_pagar_contas_CTS_1.constant.FORM.SUBLIST.LABEL,
                type: UI.SublistType.LIST
            });
            createSublist(sublist);
            sublist.addMarkAllButtons();
            var searchVendorBill = search.create({
                type: search.Type.VENDOR_BILL,
                filters: filters,
                columns: [
                    search.createColumn({ name: jtc_pagar_contas_CTS_1.constant.VENDOR_BILL.FORNECEDOR }),
                    search.createColumn({ name: jtc_pagar_contas_CTS_1.constant.VENDOR_BILL.DATA_VENCIMENTO }),
                    search.createColumn({ name: jtc_pagar_contas_CTS_1.constant.VENDOR_BILL.VALOR })
                ]
            }).run().getRange({ start: 0, end: 30 });
            log.debug('seachrVendorBill', searchVendorBill);
            if (searchVendorBill.length > 0) {
                for (var i = 0; i < searchVendorBill.length; i++) {
                    sublist.setSublistValue({
                        id: jtc_pagar_contas_CTS_1.constant.FORM.SUBLIST.FIELDS.FORNECEDOR.ID,
                        line: i,
                        value: String(searchVendorBill[i].getValue({ name: jtc_pagar_contas_CTS_1.constant.VENDOR_BILL.FORNECEDOR }))
                    });
                    sublist.setSublistValue({
                        id: jtc_pagar_contas_CTS_1.constant.FORM.SUBLIST.FIELDS.ID_TRANS.ID,
                        line: i,
                        value: searchVendorBill[i].id
                    });
                    sublist.setSublistValue({
                        id: jtc_pagar_contas_CTS_1.constant.FORM.SUBLIST.FIELDS.DATA.ID,
                        line: i,
                        value: String(searchVendorBill[i].getValue({ name: jtc_pagar_contas_CTS_1.constant.VENDOR_BILL.DATA_VENCIMENTO }))
                    });
                    sublist.setSublistValue({
                        id: jtc_pagar_contas_CTS_1.constant.FORM.SUBLIST.FIELDS.VALOR.ID,
                        line: i,
                        value: String(searchVendorBill[i].getValue({ name: jtc_pagar_contas_CTS_1.constant.VENDOR_BILL.VALOR }))
                    });
                }
            }
            form.addSubmitButton({ label: "Pagar" });
            ctx.response.writePage(form);
        }
        catch (e) {
            log.error('jtc_tela_contas_pagar_MSR.postForm', e);
            throw e;
        }
    };
    var createSublist = function (sublist) {
        try {
            var apply = sublist.addField({
                id: jtc_pagar_contas_CTS_1.constant.FORM.SUBLIST.FIELDS.APPLY.ID,
                label: jtc_pagar_contas_CTS_1.constant.FORM.SUBLIST.FIELDS.APPLY.LABEL,
                type: UI.FieldType.CHECKBOX,
            });
            var id_contas = sublist.addField({
                id: jtc_pagar_contas_CTS_1.constant.FORM.SUBLIST.FIELDS.ID_TRANS.ID,
                label: jtc_pagar_contas_CTS_1.constant.FORM.SUBLIST.FIELDS.ID_TRANS.LABEL,
                type: UI.FieldType.TEXT,
            }).updateDisplayType({ displayType: UI.FieldDisplayType.HIDDEN });
            var fonecedor_sub = sublist.addField({
                id: jtc_pagar_contas_CTS_1.constant.FORM.SUBLIST.FIELDS.FORNECEDOR.ID,
                label: jtc_pagar_contas_CTS_1.constant.FORM.SUBLIST.FIELDS.FORNECEDOR.LABEL,
                type: UI.FieldType.SELECT,
                source: String(record.Type.VENDOR)
            }).updateDisplayType({ displayType: UI.FieldDisplayType.INLINE });
            var data = sublist.addField({
                id: jtc_pagar_contas_CTS_1.constant.FORM.SUBLIST.FIELDS.DATA.ID,
                label: jtc_pagar_contas_CTS_1.constant.FORM.SUBLIST.FIELDS.DATA.LABEL,
                type: UI.FieldType.DATE
            });
            var valor = sublist.addField({
                id: jtc_pagar_contas_CTS_1.constant.FORM.SUBLIST.FIELDS.VALOR.ID,
                label: jtc_pagar_contas_CTS_1.constant.FORM.SUBLIST.FIELDS.VALOR.LABEL,
                type: UI.FieldType.CURRENCY
            });
        }
        catch (e) {
            log.error("jtc_tela_contas_pagar.createSublist", e);
        }
    };
});
